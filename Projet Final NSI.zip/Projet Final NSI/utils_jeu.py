#taille ecran
x_ecran = 1280
y_ecran = 720
size = [x_ecran, y_ecran]